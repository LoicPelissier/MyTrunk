DROP VIEW commissioned;
DROP VIEW six_figure_salary;
DROP VIEW v;

ALTER TABLE employees MODIFY email VARCHAR2(25);

DROP TABLE t2;

DROP PACKAGE pkg ;

DROP PROCEDURE p;

DROP SEQUENCE deptree_seq;
DROP TABLE deptree_temptab;

DROP VIEW deptree;
DROP VIEW ideptree;

DROP TRIGGER update_job_history;