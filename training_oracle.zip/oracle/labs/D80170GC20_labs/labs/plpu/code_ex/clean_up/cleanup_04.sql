DROP FUNCTION get_sal;
DROP FUNCTION tax;
DROP FUNCTION dml_call_sql;
DROP FUNCTION query_call_sql;
DROP PROCEDURE emp_list;
DROP FUNCTION get_location;
