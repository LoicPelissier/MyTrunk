--The SQL Script to run the solution for Practice 1

--Uncomment code below to run the solution for Task 3 of Practice 1

/*

SELECT LAST_NAME, SALARY
FROM EMPLOYEES 
WHERE SALARY > 10000;
/
*/

--Uncomment code below to run the solution for Task 4 of Practice 1

/*

SET SERVEROUTPUT ON
BEGIN
   DBMS_OUTPUT.PUT_LINE('Hello World!');
END;
/

*/

