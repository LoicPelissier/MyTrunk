--This is the SQL Script to run the code_examples for Lesson 9
--Use OE as the default connection if the connection name is not mentioned.

--Uncomment the code below to execute the code on slide 09_12sa 
/*

--Execute as sys

SELECT name, value
FROM   v$parameter
WHERE  name = 'result_cache_max_size';

*/
--Uncomment the code below to execute the code on slide 09_14sa 
/*

--Execute as sys
set serveroutput on
execute dbms_result_cache.memory_report

*/
--Uncomment the code below to execute the code on slide 09_18sa 
/*

--Execute as sys
REM flush.sql

REM Start with a clean slate. Flush the cache and shared pool. 
REM Verify that memory was released.


SET ECHO ON
SET FEEDBACK 1
SET SERVEROUTPUT ON

execute dbms_result_cache.flush
alter system flush shared_pool
/
execute dbms_result_cache.memory_report
/

*/




--Uncomment the code below to execute the code on slide 09_19sa 
/*

--Execute as OE
REM plan_query1.sql

REM Generate the execution plan.
REM (The query name Q1 is optional)

explain plan for
 select /*+ result_cache q_name(Q1) */ * from orders;


set echo off
REM Display the execution plan. Verify that the query result 
REM is placed in the Result Cache.
REM using the code in ORACLE_HOME/rdbms/admin/utlxpls


select plan_table_output from table(dbms_xplan.display('plan_table',null,'serial'));
*/

--Uncomment the code below to execute the code on slide 09_20sa 
/*

--- plan_query2.sql
set echo on

--- Generate the execution plan.
--- (The query name Q2 is optional)
explain plan for
 select c.customer_id, o.ord_count
 from (select /*+ result_cache q_name(Q2) */
      customer_id, count(*) ord_count
      from orders
      group by customer_id) o, customers c
 where o.customer_id = c.customer_id;

set echo off

--- Display the execution plan.
--- using the code in ORACLE_HOME/rdbms/admin/utlxpls


select plan_table_output from table(dbms_xplan.display('plan_table', null,'serial'));

*/
--Uncomment the code below to execute the code on slide 09_21sa
/*

--Execute as OE
--- query3.sql
--- Cache result of both queries, then use the cached result.
set timing on
set echo on

select /*+ result_cache q_name(Q1) */ * from orders
/


select c.customer_id, o.ord_count
 from (select /*+ result_cache q_name(Q3) */
      customer_id, count(*) ord_count
      from orders
      group by customer_id) o, customers c
 where o.customer_id = c.customer_id
/


set echo off

*/

--Uncomment the code below to execute the code on slide 09_22sa 
/*
  
--Execute as SYS
col name format a55
select * from v$result_cache_statistics
/

*/

--Uncomment the code below to execute the code on slide 09_23sa 
/*


--Execute as SYS
select *  from v$result_cache_statistics
 /

*/

--Uncomment the code below to execute the code on slide 09_27sa 
/*

--Execute as sys
REM flush.sql

REM Start with a clean slate. Flush the cache and shared pool. 
REM Verify that memory was released.


SET ECHO ON
SET FEEDBACK 1
SET SERVEROUTPUT ON

execute dbms_result_cache.flush
alter system flush shared_pool
/
execute dbms_result_cache.memory_report
/
*/

--Uncomment the code below to execute the code on slide 09_28sa 
/*

--Execute as OE
--- cre_func.sql

--- Create a function that populates the cache

CREATE OR REPLACE FUNCTION ORD_COUNT(cust_no number)
RETURN NUMBER
RESULT_CACHE RELIES_ON (orders)
IS
 V_COUNT NUMBER;
BEGIN
 SELECT COUNT(*) INTO V_COUNT
 FROM orders
 WHERE customer_id = cust_no;

 return v_count;
end;
/ 
*/

--Uncomment the code below to execute the code on slide 09_29sa
/*

--Execute as OE
--- call_func.sql

--- Call a caching PL/SQL function


SELECT cust_last_name, ORD_COUNT(customer_id) no_of_orders
FROM customers
WHERE cust_last_name = 'MacGraw'
/
*/

--Uncomment the code below to execute the code on slide 09_30sa 
/*

--Execute as sys
col name format a55
select *
from v$result_cache_statistics
/
*/
--Uncomment the code below to execute the code on slide 09_31sa 
/*

--Execute as OE
--- call_func.sql

--- Call a caching PL/SQL function


SELECT cust_last_name, ORD_COUNT(customer_id) no_of_orders
FROM customers
WHERE cust_last_name = 'MacGraw'
/
*/
--Uncomment the code below to execute the code on slide 09_32sa
/*

--Execute as sys
col name format a55
select *
from v$result_cache_statistics
/
*/
--Uncomment the code below to execute the code on slide 09_33sa 
/*

--Execute as sys
col name format a55
select type, namespace,status, scan_count,name
from v$result_cache_objects
/
*/

